<template>
  <div>
    <h2>X page</h2>
  </div>
</template>

<script></script>
