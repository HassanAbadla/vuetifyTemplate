<template>
  <v-container>
    <h1>This is the lesson page</h1>
    <h4>layouts</h4>
    <p>paragraph</p>
    <span>span</span>
    <small>small</small>

    <v-text-field v-model="first_name" label="First name"></v-text-field>
    <p>{{ first_name }}</p>

    <v-container>
      <v-card>
        <p>{{ item.first_name }} -- {{ item.last_name }}</p>
      </v-card>
    </v-container>
    <v-card>
      <div v-for="sand in items" :key="item.id">
        <p>{{ sand.first_name }} {{ sand.last_name }}</p>
      </div>
    </v-card>

    <div>
      <p>Haneen Dow</p>
      <p>Hassan Dow</p>
    </div>
  </v-container>
</template>

<script>
  export default {
    name: "lesson",
    compnents: {},
    layout: "default",
    data() {
      return {
        first_name: "",

        item: {
          id: 1,
          first_name: "John",
          last_name: "Doe",
        },

        items: [
          {
            id: 1,
            first_name: "Hassan",
            last_name: "Doe",
          },
          {
            id: 2,
            first_name: "Alaa",
            last_name: "Doe",
          },
          {
            id: 3,
            first_name: "Youssif",
            last_name: "Doe",
          },
        ],
      }
    },

    methods: {},

    computed: {},
  }
</script>
