<template>
  <v-container>
    <h1>This is the lesson one page</h1>
    <h4>file structure</h4>
  </v-container>
</template>

<script></script>
